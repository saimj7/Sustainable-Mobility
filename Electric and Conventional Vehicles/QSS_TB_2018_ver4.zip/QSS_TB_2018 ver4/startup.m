qss_tb_library
